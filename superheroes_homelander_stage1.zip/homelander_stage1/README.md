# Superheroes — Homelander Stage 1

Minecraft Forge **1.20.1**, Java **17**, Forge **47.4.28**.

## Current implementation
- Hold Z: Heat Vision; release Z to stop; server-side beam damage tick.
- X: Clap shockwave-style nearby cone attack (6 damage points = 3 hearts).
- C: Launch target in front upward (prototype; cinematic slam is not yet implemented).
- R: grab/release a living target in front (prototype; escape QTE and throw charge are not yet implemented).
- Double-tap Space: toggle flight (prototype; flight animation states are not yet implemented).
- Vertical bottom-right ability HUD.
- 60-second laser overuse triggers a temporary Burnout lockout, then a 90-second Rage timer.
- Server-side cooldown tracking for Clap (20s) and Launch (30s).

## Important status
This is the first source-project foundation, not the finished high-fidelity mod. The reference images are design references; they are not a 3D mesh or a usable UV texture. The detailed Homelander player model, accurate costume texture, animated cape, custom flight animations, full Burnout/Launch cinematics, laser eye charge visuals, complete Rage powers, and the finished grab/throw sequence still need to be authored and tested in-game.

## Build
Run `gradle clean build` with Java 17 and Gradle 8.8+, or push the repository to GitHub and run the included Actions workflow. The built JAR is uploaded as the workflow artifact.
