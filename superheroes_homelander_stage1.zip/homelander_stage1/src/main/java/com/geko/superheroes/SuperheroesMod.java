package com.geko.superheroes;

import com.geko.superheroes.network.ModNetwork;
import net.minecraftforge.fml.common.Mod;

@Mod(SuperheroesMod.MODID)
public class SuperheroesMod {
    public static final String MODID = "superheroes";
    public SuperheroesMod() {
        ModNetwork.register();
    }
}
