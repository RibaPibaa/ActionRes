package com.geko.superheroes.ability;

import com.geko.superheroes.SuperheroesMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SuperheroesMod.MODID)
public final class ServerEvents {
    private ServerEvents() {}
    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        HomelanderAbilities.tick(player);
        HomelanderAbilities.cooldownTick(player);
    }
}
