package com.geko.superheroes.client;

import com.geko.superheroes.SuperheroesMod;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SuperheroesMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientSetup {
    private ClientSetup() {}
    private static final IGuiOverlay ABILITY_HUD = (gui, pose, partialTick, width, height) -> {
        if (gui.getMinecraft().player == null) return;
        int x = width - 92;
        int y = height - 104;
        String[][] entries = {{"Z", "HEAT VISION"}, {"X", "CLAP"}, {"C", "LAUNCH"}, {"R", "GRAB"}};
        for (int i = 0; i < entries.length; i++) {
            int yy = y + i * 23;
            pose.fill(x, yy, x + 86, yy + 19, 0xA9000000);
            pose.fill(x, yy, x + 20, yy + 19, 0xFF8F1D25);
            pose.drawString(net.minecraft.client.Minecraft.getInstance().font, entries[i][0], x + 6, yy + 5, 0xFFFFFFFF, false);
            pose.drawString(net.minecraft.client.Minecraft.getInstance().font, entries[i][1], x + 25, yy + 5, 0xFFE8E3D8, false);
        }
    };
    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "homelander_abilities", ABILITY_HUD);
    }
}
