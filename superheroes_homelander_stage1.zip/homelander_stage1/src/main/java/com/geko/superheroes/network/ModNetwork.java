package com.geko.superheroes.network;

import com.geko.superheroes.SuperheroesMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SuperheroesMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static boolean registered;
    private ModNetwork() {}
    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.messageBuilder(AbilityPacket.class, 0)
                .encoder(AbilityPacket::encode).decoder(AbilityPacket::decode)
                .consumerMainThread(AbilityPacket::handle).add();
    }
}
