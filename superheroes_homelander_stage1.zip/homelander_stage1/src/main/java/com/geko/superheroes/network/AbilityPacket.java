package com.geko.superheroes.network;

import com.geko.superheroes.ability.HomelanderAbilities;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class AbilityPacket {
    private final int action;
    public AbilityPacket(int action) { this.action = action; }
    public static void encode(AbilityPacket msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.action); }
    public static AbilityPacket decode(FriendlyByteBuf buf) { return new AbilityPacket(buf.readVarInt()); }
    public static void handle(AbilityPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) HomelanderAbilities.handle(player, msg.action);
        });
        context.setPacketHandled(true);
    }
}
