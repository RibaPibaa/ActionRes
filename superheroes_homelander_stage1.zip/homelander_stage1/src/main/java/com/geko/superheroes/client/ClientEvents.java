package com.geko.superheroes.client;

import com.geko.superheroes.SuperheroesMod;
import com.geko.superheroes.network.ModNetwork;
import com.geko.superheroes.network.AbilityPacket;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = SuperheroesMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientEvents {
    public static KeyMapping LASER, CLAP, LAUNCH, GRAB;
    private static final String CATEGORY = "key.categories.superheroes";
    private ClientEvents() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        LASER = new KeyMapping("key.superheroes.laser", GLFW.GLFW_KEY_Z, CATEGORY);
        CLAP = new KeyMapping("key.superheroes.clap", GLFW.GLFW_KEY_X, CATEGORY);
        LAUNCH = new KeyMapping("key.superheroes.launch", GLFW.GLFW_KEY_C, CATEGORY);
        GRAB = new KeyMapping("key.superheroes.grab", GLFW.GLFW_KEY_R, CATEGORY);
        event.register(LASER); event.register(CLAP); event.register(LAUNCH); event.register(GRAB);
    }

    @Mod.EventBusSubscriber(modid = SuperheroesMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeClientEvents {
        private static boolean laserWasDown = false;
        private static long lastJumpPress = 0L;
        @SubscribeEvent
        public static void keyInput(InputEvent.Key event) {
            if (event.getKey() == GLFW.GLFW_KEY_SPACE && event.getAction() == GLFW.GLFW_PRESS) {
                long now = System.currentTimeMillis();
                if (now - lastJumpPress < 350) ModNetwork.CHANNEL.sendToServer(new AbilityPacket(5));
                lastJumpPress = now;
            }
        }
        @SubscribeEvent
        public static void clientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END || Minecraft.getInstance().player == null) return;
            boolean laserDown = LASER.isDown();
            if (laserDown != laserWasDown) {
                ModNetwork.CHANNEL.sendToServer(new AbilityPacket(laserDown ? 0 : 4));
                laserWasDown = laserDown;
            }
            while (CLAP.consumeClick()) ModNetwork.CHANNEL.sendToServer(new AbilityPacket(1));
            while (LAUNCH.consumeClick()) ModNetwork.CHANNEL.sendToServer(new AbilityPacket(2));
            while (GRAB.consumeClick()) ModNetwork.CHANNEL.sendToServer(new AbilityPacket(3));
        }

    }
}
