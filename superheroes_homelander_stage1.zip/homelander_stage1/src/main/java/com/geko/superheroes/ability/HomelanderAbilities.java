package com.geko.superheroes.ability;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.InteractionHand;
import java.util.*;

public final class HomelanderAbilities {
    private static final Map<UUID, Integer> LASER_TICKS = new HashMap<>();
    private static final Map<UUID, UUID> GRABBED = new HashMap<>();
    private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
    private HomelanderAbilities() {}

    public static void handle(ServerPlayer player, int action) {
        if (action == 0) { startLaser(player); return; }
        if (action == 4) { LASER_TICKS.remove(player.getUUID()); return; }
        if (action == 5) { toggleFlight(player); return; }
        if (player.getPersistentData().getBoolean("superheroes_burnout")) return;
        switch (action) {
            case 1 -> clap(player);
            case 2 -> launch(player);
            case 3 -> grabOrRelease(player);
        }
    }

    private static void startLaser(ServerPlayer p) {
        if (p.getPersistentData().getBoolean("superheroes_burnout")) return;
        LASER_TICKS.putIfAbsent(p.getUUID(), 0);
    }

    public static void tick(ServerPlayer p) {
        UUID id = p.getUUID();
        Integer ticks = LASER_TICKS.get(id);
        if (ticks != null) {
            ticks++;
            LASER_TICKS.put(id, ticks);
            if (ticks >= 1200) {
                LASER_TICKS.remove(id);
                p.getPersistentData().putBoolean("superheroes_burnout", true);
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, 100, 4));
                p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 100, 10));
                p.displayClientMessage(net.minecraft.network.chat.Component.literal("BURNOUT"), true);
                p.getPersistentData().putInt("superheroes_burnout_ticks", 0);
            } else if (ticks % 4 == 0) fireLaser(p);
        }
        if (p.getPersistentData().getBoolean("superheroes_burnout")) {
            int t = p.getPersistentData().getInt("superheroes_burnout_ticks") + 1;
            p.getPersistentData().putInt("superheroes_burnout_ticks", t);
            if (t >= 100) {
                p.getPersistentData().putBoolean("superheroes_burnout", false);
                p.getPersistentData().putInt("superheroes_burnout_ticks", 0);
                p.getPersistentData().putInt("superheroes_rage_ticks", 1800);
            }
        }
        int rage = p.getPersistentData().getInt("superheroes_rage_ticks");
        if (rage > 0) p.getPersistentData().putInt("superheroes_rage_ticks", rage - 1);
        UUID targetId = GRABBED.get(id);
        if (targetId != null) {
            Entity target = p.serverLevel().getEntity(targetId);
            if (target == null || !target.isAlive()) GRABBED.remove(id);
            else target.teleportTo(p.getX() + p.getLookAngle().x * 1.1, p.getY() + 0.8, p.getZ() + p.getLookAngle().z * 1.1);
        }
    }

    private static void fireLaser(ServerPlayer p) {
        Vec3 start = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        AABB area = p.getBoundingBox().expandTowards(dir.scale(28)).inflate(1.0);
        for (LivingEntity target : p.level().getEntitiesOfClass(LivingEntity.class, area, e -> e != p && e.isAlive())) {
            Vec3 to = target.getBoundingBox().getCenter().subtract(start);
            double along = to.dot(dir);
            if (along > 0 && along < 28 && to.subtract(dir.scale(along)).lengthSqr() < 0.8) {
                target.hurt(p.damageSources().playerAttack(p), p.getPersistentData().getInt("superheroes_rage_ticks") > 0 ? 4.0F : 2.0F);
                target.setSecondsOnFire(2);
            }
        }
    }

    private static void clap(ServerPlayer p) {
        if (!ready(p, "clap", 400)) return;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(5), x -> x != p && x.isAlive())) {
            Vec3 delta = e.position().subtract(p.position());
            if (delta.lengthSqr() < 25 && p.getLookAngle().dot(delta.normalize()) > 0.45) {
                e.hurt(p.damageSources().playerAttack(p), 6.0F);
                e.knockback(1.4, -p.getLookAngle().x, -p.getLookAngle().z);
            }
        }
        p.swing(InteractionHand.MAIN_HAND, true);
    }

    private static void launch(ServerPlayer p) {
        if (!ready(p, "launch", 600)) return;
        LivingEntity target = lookTarget(p, 2.0);
        if (target == null) return;
        target.hurt(p.damageSources().playerAttack(p), 4.0F);
        target.setDeltaMovement(0, 1.6, 0);
        target.hurtMarked = true;
        p.setDeltaMovement(p.getLookAngle().scale(0.7).add(0, 0.45, 0));
        p.hurtMarked = true;
        target.getPersistentData().putInt("superheroes_launch_ticks", 20);
    }

    private static void grabOrRelease(ServerPlayer p) {
        UUID id = p.getUUID();
        if (GRABBED.containsKey(id)) { GRABBED.remove(id); return; }
        LivingEntity target = lookTarget(p, 2.0);
        if (target != null && target != p) {
            GRABBED.put(id, target.getUUID());
            target.setDeltaMovement(Vec3.ZERO);
            target.hurtMarked = true;
        }
    }

    private static LivingEntity lookTarget(ServerPlayer p, double range) {
        Vec3 start = p.getEyePosition();
        Vec3 end = start.add(p.getLookAngle().scale(range));
        AABB box = p.getBoundingBox().expandTowards(p.getLookAngle().scale(range)).inflate(0.8);
        return p.level().getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive()).stream()
                .filter(e -> e.getBoundingBox().clip(start, end).isPresent())
                .min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).orElse(null);
    }

    private static void toggleFlight(ServerPlayer p) {
        boolean enabled = !p.getPersistentData().getBoolean("superheroes_flight");
        p.getPersistentData().putBoolean("superheroes_flight", enabled);
        p.getAbilities().mayfly = enabled;
        if (!enabled) p.getAbilities().flying = false;
        p.onUpdateAbilities();
    }

    private static boolean ready(ServerPlayer p, String key, int ticks) {
        String tag = "superheroes_cd_" + key;
        int remaining = p.getPersistentData().getInt(tag);
        if (remaining > 0) return false;
        p.getPersistentData().putInt(tag, ticks);
        return true;
    }

    public static void cooldownTick(ServerPlayer p) {
        for (String key : List.of("clap", "launch")) {
            String tag = "superheroes_cd_" + key;
            int n = p.getPersistentData().getInt(tag);
            if (n > 0) p.getPersistentData().putInt(tag, n - 1);
        }
    }
}
